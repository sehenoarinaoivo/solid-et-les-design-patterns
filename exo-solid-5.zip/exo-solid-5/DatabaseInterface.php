<?php

interface DatabaseInterface
{    
    public function fetchAll() : array;
}
